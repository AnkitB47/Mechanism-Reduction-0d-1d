HP-POX SENSITIVITY Results
==================================================

Generated: 2025-09-29T09:08:17.317432
Case: sensitivity
Mechanism: Detailed

Files:
- axial_profiles.csv: Axial profiles data
- axial_profiles_plot.png: Axial profiles plot
- ignition_length_markers.png: Ignition length detection
- outlet_barplot.png: Outlet composition bar plot
- outlet_composition_table.csv: Outlet composition data
- kpis.json: Key performance indicators
