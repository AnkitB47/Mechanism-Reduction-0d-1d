HP-POX Model Results
===================

Case: Case 4 (50 bar(g), target 1400�C)
Pressure: 50.0 bar(g)
Target Temperature: 1400.0�C

Geometry:
  PSR Volume: 0.016136 m�
  PFR Length: 2.32 m
  PFR Diameter: 0.49 m
  Wall Temperature: 418.0 K

Heat Loss:
  Burner Cooling: 36.4 kW
  Reactor Wall: 22.9 kW

Files:
  axial_profiles.csv - Axial profiles (z, T, P, u, Y_i, X_i)
  axial_profiles_plot.png - 4-panel plot of axial profiles
  ignition_length_markers.png - Temperature with ignition markers
  outlet_composition_table.csv - Wet and dry compositions
  outlet_barplot.png - Outlet composition bar chart
  kpis.json - Complete KPI dictionary
